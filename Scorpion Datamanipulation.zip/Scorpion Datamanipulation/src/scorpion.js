const axios = require('axios');
const cheerio = require('cheerio');
const commander = require('commander');
const path = require('path');
const fs = require('fs');
const ExifParser = require('exif-parser');

// Define the path to the image file
const imagePath = 'Dobe.jpeg'; // Replace with the path to your image file

// Read the image file and get its stats (including creation date)
fs.stat(imagePath, (err, stats) => {
  if (err) {
    console.error('Error reading file:', err);
    return;
  }

  // Display the name of the file and its creation date
  const fileName = imagePath.split('/').pop(); // Get the file name from the path
  const creationDate = stats.birthtime; // Get the creation date
  console.log(`File Name: ${fileName}`);
  console.log(`File Creation Date: ${creationDate}`);

  // Read the image file
  fs.readFile(imagePath, (err, imageBuffer) => {
    if (err) {
      console.error('Error reading image file:', err);
      return;
    }

    // Create an ExifParser instance and parse the image data
    const exifParser = ExifParser.create(imageBuffer);
    const result = exifParser.parse();

    // Display the parsed EXIF data
    console.log('EXIF Data:', result);
  });
});